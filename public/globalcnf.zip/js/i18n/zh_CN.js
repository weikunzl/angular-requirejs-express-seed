
var _translate_ZH = {
  "yangtitle": "外国男人、外国男朋友、外国老公、外国丈夫、洋知己、哪里找？专业为您找老外的网站-洋老公",
  "Sharetitle": "perdate-学各国语言，遇最爱的TA",
  "ShareContent": "多语言国际亲密交友第一阵地,不用环球旅行，世界就在你身边。",
  "bgcupid_txt1": "国际交友",
  "bgcupid_txt2": "足不出户知己全球",
  "bgcupid_txt3": "邂逅缘分",
  "bgcupid_txt4": "与梦中情人相遇",
  "bgcupid_txt5": "亲密聊天",
  "bgcupid_txt6": "随时随地随心畅聊",
  "bgcupid_txt7": "智能翻译",
  "bgcupid_txt8": "沟通障碍一扫光",
  "SeeRecommended": "查看推荐",
  "SeeEncounter": "开始邂逅",
  "AddNews": "发表新鲜事",
  "perfreshNewContent": "您还没有新鲜事",
  "NewContent": "对方还没有新鲜事",
  "RecentText": "您还没有联系人",
  "SearchText": "对不起,没有找到相关的人",
  "upgradeName": "支付方式",
  "Transwall_content1": "自动翻译时每个字符仅收",
  "Transwall_content2": "人工翻译时每个字符仅收",
  "chattxtem": "消息不能为空",
  "titlehome1": "神奇邂逅助手",
  "titlehome2": "专业人工翻译",
  "titlehome3": "更多功能",
  "FooterQuickcontent": "或",
  "LogOuts": "您还没有登录，请登录",

  "Landed": "登陆"

,"Register": "注册"

,"Username": "用户名"

,"EnterUsername": "输入用户名"

,"Mailbox": "邮箱"

,"EnterMailbox": "输入邮箱"

,"Password": "密码"

,"EnterPassword": "输入密码"

,"ForgotPassword": "忘记密码",
"Quicklogin": "其他账号登录",
"emailandphone": "输入您的email或手机号"

,"register_input_name": "请输入您的昵称"

,"register_input_name_e": "请输入6 ~ 20 字符【0-9】【a-z-A-Z】"
,"register_input_email": "请输入您的邮箱"

,"register_input_psw": "请输入您的密码"

,"register_clause1": "继续表示您接收我们的"

,"register_clause2": "和"

,"register_clause3": "我们绝不会分享您的联系方式"

,"register_oauth": "为了您更方便的使用本网站，请完善以下信息。您设置的的邮箱和密码可以登陆网站使用，请谨慎填写。"

,"ForgotPasswordCont": "请输入注册时的邮箱，我们会发送找回密码到您的注册邮箱中，请注意查收"

,"Phone_code": "验证短信已发送至"

,"Recommendedwall_content": "让更多的人看到自己 , 仅须10金币"
,"Forgot_send": "发送"

,"lang_Phone": "手机验证"

,"PVp_r_su": "下一步"

,"lang_VerificationCode": "填写验证码"

,"lang_country": "选择国家"

,"VerificationCode": "请输入验证码"

,"VCsp_r_su": "重新获取"

,"GoldNO": "您的金币不足，请充值！"

,"Sex": "性别"

,"Birthday": "生日"

,"SelectBirthday": "选择生日"

,"logins1": "账号已存在或格式不对！请重新输入！"

,"logins2": "密码格式不对！请重新输入！"

,"logins3": "邮箱已存在！请重新输入！"

,"logins4": "服务器错误！请重新输入！"

,"login_email": "您输入的邮箱没有在网站注册",
"login_email_cont": "请输入Email",
"register_email": "邮箱已注册过，请直接登陆或更换其他邮箱",
"register_Verification": "验证码错误",
"register_Phone": "手机已存在",
"register_name": "昵称为空或包含perdate或yangmeizi",
"register_sex": "性别不正确",
"register_text": "注册信息填写错误，请仔细检查更正后再提交",
"register_Phone_cont": "手机号已存在或格式错误，请从新输入",
"register_Phone_v": "请输入手机号",
"register_Phone_em": "手机号不能为空",
"checkUsers": "用户名不能为空",
"checkpwds": "密码不能为空",
"checkEmails": "邮箱不能为空",
"checkEmailmyreg": "邮箱格式不对",
"Encounter": "邂逅"

,"ReciprocalLiking": "相互喜欢"

,"ILikeThes": "我喜欢的"

,"LikeMys": "喜欢我的"

,"likes": "你喜欢他/她吗?"
,"Determine": "确定"
,"cancel": "取消",
"ExitAccount_1": "提示"
,"ExitAccount_2": "是否退出？"
,"ConfirmPassword": "确认密码"
,"searchTitle": "搜索"
,"searchAge": "年龄段"
,"searchBotton": "立即搜索"
,"searchok": "完成"
,"successfuls": "成功"
,"failure": "失败"
,"Goldfailure": "您的金币不足请充值！"
,"GoldCoin": "金币"
,"Giftcontent": "您还没有收到礼物"
,"Gifttodescribe": "礼物描述"
,"Giftisintroduced": "礼物介绍"
,"Contactus": "联系我们"
,"Secondsbefore": "秒以前"
,"Pointsbefore": "分以前"
,"Hoursago": "小时以前"
,"Daysago": "天以前"
,"Moreandmore": "更多"
,"chatlang": "聊天"
,"gifts": "礼物"
,"Deletes": "删除"
,"Shutdown": "关闭"
,"quicklymeet": "相识相知，就是现在"
,"quicklymeet1": "爱情，从跟他/她say hi 开始"
,"quicklymeet2": "懂你的都在这里"
,"collection": "您暂时还没有收藏"
,"ExpressionPostShop": "表情贴商店"
,"Recentcontact": "最近联系人"
,"Onlineuserss": "在线用户"
,"homepage": "主页"
,"freshNews": "新鲜事"
,"Golddeposits": "金币充值"
,"GetGold": "获取金币"
,"personalhomepages": "个人主页"
,"Photoalbum": "相册"
,"AddAlbum": "创建相册"
,"upgrade": "升级"
,"shoppingmall": "商城"
,"HaveDownloaded": "已下载"
,"buy": "购买"

,"BuySuccess": "购买成功"

,"PurchaseFailed": "购买失败，请从新购买"
,"collections": "收藏"
,"visiting": "来访"
,"GiftBox": "礼物盒子"
,"settingUp": "设置"
,"ChangePasswords": "修改密码"
,"AboutUs": "关于我们"
,"DatingSafetys": "交友安全"
,"TermsOfUses": "使用条款"
,"PrivacyPolicys": "隐私政策"
,"HeadPortrait": "上传头像"
,"WithdrawFromTheAccount": "退出账号"

,"UploadThePicture": "上传了头像"
,"uploadPictures": "上传照片"
,"UploadPhotoBotton": "选择照片"
,"relection": "重选"
,"uploading": "上传"
,"realgifts": "真实礼物"
,"Introduceyourself": "向大家介绍一下自己吧"
,"Introduce": "来问我吧"
,"boy": "男"
,"girl": "女"
,"Toaskme": "来问我"
,"visitors": "您目前还没有访客"
,"TwoPassword": "两次密码输入不一致！"

,"UploadPhotos": "上传了照片"

,"translation": "翻译"
,"BalanceOfGoldCOINS": "金币余额"

,"Choosetopup": "选择充值金额"

,"PrepaidPhoneImmediately": "立即充值"

,"plans": "有何打算？"
,"MEMBERS": "会员专享"

,"Interested": "无限发信&无限会员查看"

,"SendReceive": "访问查询&喜欢的人查看"

,"opposites": "免费谷歌翻译"

,"UpgradeDiamond": "升级成钻石用户"

,"months": "月"

,"years": "年"

,"save": "节省"

,"Upgradedcrown": "VIP会员"

,"AboutMy": "关于"

,"Avatar": "修改头像"

,"AboutMyself": "关于自己"

,"AboutMyselfC": "向大家介绍一下自己吧"

,"EssentialInformation": "基本信息"

,"languages": "语言"

,"weights": "体重"

,"heights": "身高"

,"AffectionIsIntroduced": "感情介绍"

,"SexualOrientation": "性取向"

,"EmotionalState": "感情状态"

,"geographicPosition": "地理位置"

,"countries": "国家"

,"citys": "城市"

,"EducationWork": "教育/工作"

,"Education": "教育"

,"works": "工作"

,"incomes": "收入"

,"defaults": "默认",
"icons": "头像",
"ConfirmToSendOut": "确认送出"

,"historys": "历史记录",

  "fanyi_close": "不翻译",
  "Automatic_translation": "自动翻译",
  "Manual_translation": "手动翻译",
  "sticker_imphoto": "图片",
  "tranno": "没有可翻译的内容！",
  "UpgradePrompt": "会员功能，请升级",
  "logemail": "请查收电子邮件并根据说明恢复您的密码。您可能需要等待几分钟才能收到此邮件。",
  "giftall": "全部",
  "giftBirthday": "生日",
  "giftFriendship": "友谊",
  "giftLove": "爱情",
  "giftFestival": "节日",
  "giftFun": "搞笑",
  "giftsarray": [
    "礼物",
    "爱情",
    "友谊",
    "生日",
    "节日",
    "搞笑"
  ],
  "weight": [
    "不足 40 kg (88 pounds)",
    "41 - 50 kg (90 - 110 pounds)",
    "51 - 60 kg (111 - 132 pounds)",
    "61 - 70 kg (133 - 155 pounds)",
    "71 - 80 kg (156 - 176 pounds)",
    "81 - 90 kg (177 - 199 pounds)",
    "91 - 100 kg (200 - 220 pounds)",
    "超过 100 kg (220 pounds)"
  ],
  "height": [
    "低于 150 cm (5'0')",
    "151 - 160 cm (5'0' - 5'2')",
    "161 - 170 cm (5'2' - 5'6')",
    "171 - 180 cm (5'6' - 5'9')",
    "181 - 190 cm (5'9' - 6'2')",
    "高于191 cm (6'2')"
  ],
  "sexuality": [
    "异性",
    "开放",
    "双性",
    "同性"
  ],
  "relationship": [
    "单身",
    "恋爱中",
    "订婚",
    "已婚",
    "不好说",
    "开放式的交往方式",
    "丧偶",
    "分居",
    "离婚",
    "同性伴侣"
  ],
  "education": [
    "中小学",
    "专科/技校",
    "学院/大学",
    "更高学位"
  ],
  "income": [
    "不足 $30,000",
    "$30,000 - $45,000",
    "$45,000 - $60,000",
    "$60,000 - $75,000",
    "$75,000 - $150,000",
    "超过 $250,000"
  ],
  "language_name": [
    "中文简体",
    "中文繁体",
    "English",
    "日本語",
    "韩国",
    "Deutsch",
    "Español",
    "Français",
    "Italiano",
    "Nederlands",
    "Português",
    "Русский"
  ],
  "language_id": [
    "zh",
    "zh-TW",
    "en",
    "ja",
    "ko",
    "de",
    "es",
    "fr",
    "it",
    "nl",
    "pt",
    "ru"
  ],
  "commonly_Country": "常用",
  "All_Country": "全部",
  "PhoneCountry": [
    "中国   (+86)",
    "台湾   (+886)",
    "香港   (+852)",
    "俄罗斯   (+7)",
    "美国   (+1)",
    "加拿大   (+1)",
    "日本   (+81)",
    "韩国   (+82)",
    "德国   (+49)",
    "西班牙   (+34)",
    "法国   (+33)",
    "意大利   (+39)",
    "荷兰   (+86)",
    "葡萄牙   (+86)",
    "新西兰   (+64)"
  ],
  "nubmer_p": "请输入您的手机号！",
  "DAtingSafetycontent1": "在 perdate ，我们非常严肃地保护会员的隐私。我们始终一贯地管理网站上所有的个人主页、照片和所使用的语言，并尽一切所能保护你的隐私和安全。然而，我们要提醒你：网上安全也是你的责任，这非常重要。所以要小心，三思而后行。保护自己的安全！",
  "DAtingSafetycontent2": "不要向任何第三方 - 即使是您的朋友 - 分享或透露您的密码。如果您丢失或泄露您的密码，可能会危及您的私人数据。如果您的个人档案被黑客入侵，请您通过我们的反馈页面向我们团队进行举报。",
  "DAtingSafetycontent3": "当您对新认识的人还不太了解时，请您不要轻易泄露个人信息。这包括透露您的电子邮件地址，即时通信的联系方式，全名及URL。请您千万不要告诉他人您的财务信息，如信用卡资料等。",
  "DAtingSafetycontent4": "有些骗子会假冒我们公司或其他公司的代表要求您为非perdate网站直接提供的所谓奖品的快递或服务付款，因此请您一定要特别警惕。尤其请您要注意的是，当有人说他们有困难而向您要钱时 - 这种情况通常是骗局。",
  "DAtingSafetycontent5": "如 果您遇到任何不恰当的行为，点击举报违规行为的链接后，我们团队会马上收到该报告。如果您与某位会员交流时觉得不自在，您也能找到阻止该会员的选项。不要 忍受任何无礼或骚扰行为 - 阻止该会员或向我们的客户服务团队举报。我们会尽快处理这些事宜，我们拥有一个完善的监管系统对这方面进行监控和质量控制。",
  "DAtingSafetycontent6": "关于线下见面的提示",
  "DAtingSafetycontent7": "当您与刚认识的新会员交谈时，问他们要最近拍的照片 - 最好是在过去4个星期内拍的",
  "DAtingSafetycontent8": "千万不要迫使自己去与对方见面；只有当您准备好的时候才可以去见面。",
  "DAtingSafetycontent9": "把您打算去的地方告诉您的朋友，并且让他们给您打电话或发短信以确认您的安全。请您确保带上电量充满并且余额足够的手机，并且及时把见面的情况和何时安全到家告知你的朋友。",
  "DAtingSafetycontent10": "请您自己安排前往和离开见面地点的交通工具 - 不要在对方或自己的家里见面。最好永远不要泄露您的住址，除非您与对方已经非常熟悉。",
  "DAtingSafetycontent11": "请您确保将第一次见面安排在白天以及公共场所，并且在您清醒时！请您千万不要在见面时喝太多酒，并且时时将自己的随身物品和饮品放在自己的眼前。",
  "PrivacyPolicyContent1": "perdate尊重用户的隐私权，并制定隐私政策，保护您的隐私权。隐私政策包括：perdate的用户情况，我们所收集的信息，怎样利用这些信息，以及与谁分享这些信息。当您使用我们的网站或服务，或与我们进行商务交易时，我们建议你仔细阅读“隐私政策”。通过使用我们的网站，表明您已接受本保密协议的规定。perdate非常重视网络隐私。如果您对该隐私政策有任何疑问，请联系我们。",
  "PrivacyPolicyContent2": "未满18岁的人士",
  "PrivacyPolicyContent3": "perdate不会故意收集或保存未满18岁人士的个人验证信息或非个人验证信息，本网站下的任何项目均不面向未满18岁的人士开放。如果你未满18岁，请停止使用或禁止进入本网站或服务。如果perdate获悉所收集的信息中有未满18岁人士的个人验证信息，本网站将采取合理的步骤，删除该信息。",
  "PrivacyPolicyContent4": "我们所收集的信息",
  "PrivacyPolicyContent5": "我们收集并处理以下信息：您填写的相关信息（包括您的个人信息，联系信息，以及当您创建会员档案时所填写的其他档案信息）。同时，我们也收集以下信息：当你自由填写顾客调查表，提供反馈和参与竞争时，所提供的相关信息。如果您与我们联系，我们会记录你的通信信息。交易信息包括您从我们网站定购有关产品和服务的信息。浏览我们网站的访客，并且他们的信息已被记录的，可以有权以相同的信息登录，并有权更正信息或查看有关该信息的政策和规则。访客可以直接与我们联系。",
  "PrivacyPolicyContent6": "其他方收集的信息",
  "PrivacyPolicyContent7": "我们允许第三方（包括我们的授权服务提供商，广告公司和广告网站）在我们的网站上发表广告。如果你打开一个链接（例如一个广告标志），这将使你将离开我们的网站，登录其他的网站，如果你随后在其他网站上提供信息，我们将不能控制该信息的使用。本隐私政策将不对其他网站或广告商的信息保密负责。对于其他网站如何使用你的信息，perdate也将不为此负担任何责任。",
  "PrivacyPolicyContent8": "我们怎样使用收集的信息？",
  "PrivacyPolicyContent9": "我们按以下方式使用所收集的用户信息：管理您的用户账户（包括：通知您任何匹配的对象，提示，通告，更新资料或促销活动）帮助你订制个性化的网站回访向您提供您所询问的信息，产品或服务，或者你感兴趣的信息进行市场分析和调查帮助我们改进服务结构，布局和适用性",
  "PrivacyPolicyContent10": "我们与谁分享所收集的信息",
  "PrivacyPolicyContent11": "我们可能在特定方面将您的信息与第三方分享，例如：当您从我们网站订制服务时，我们提供你的信息给第三方进行付款处理。但是我们将控制第三方使用您的信息，并对此负责。我们有可能将您的某些信息透露给我们的合作公司，以便向您提供服务，例如：邮件或聊天功能服务。为了提供这些服务，我们必须将您的信息（包括您的perdate用户名和email地址）提供给我们的合作伙伴。",
  "PrivacyPolicyContent12": "变更隐私政策",
  "PrivacyPolicyContent13": "我们经常审核“隐私政策”，并在此页面公布政策的变更信息。我们鼓励会员经常审核我们的隐私政策，以便更好地了解我们所收集的信息，以及我们怎样运用信息，以及在何种情况下使用信息，与他人分享信息。",
  "PrivacyPolicyContent14": "怎样联系我们",
  "PrivacyPolicyContent15": "如果您对于本隐私政策或对于我们的信息处理方式有何疑问，或对于我们透露信息给第三方（为了直销的目的）有疑问，请通过email或信件与联系我们。perdateteams@gmail.com",
  "TermsOfUseContent1": "perdate订立了有关网站服务（以下简称服务）的下述协议（“使用条款”）。无论谁使用我们的服务，都被视为已同意遵守我们的使用条款。",
  "TermsOfUseContent2": "同意使用条款",
  "TermsOfUseContent3": "本协议（使用条款）包括现在和未来所经营的网站及客户端。通过使用此服务，无论您是否注册成为perdate的会员（以下简称为会员），您将被视为已经同意这些使用条款。如果您不同意此服务条款，请您停止使用我们的服务。",
  "TermsOfUseContent4": "合格要求",
  "TermsOfUseContent5": "年龄未满18岁的未成年人不得使用我们的服务。通过使用我们的服务，您已声明并保证您有权利和能力遵守使用条款的所有规定。",
  "TermsOfUseContent6": "使用条款的变更",
  "TermsOfUseContent7": "perdate有权在无需事先通知的情况下，变更本使用条款。您可以定期查看服务条款的变更情况。 当我们对使用条款进行变更后，如果您使用我们的服务，无论您浏览与否，即视为您同意这些变更。",
  "TermsOfUseContent8": "隐私",
  "TermsOfUseContent9": "perdate尊重网站访问者的隐私权。服务的使用应遵循我们的隐私权政策。perdate的合作伙伴同意遵循隐私权政策的规定。",
  "TermsOfUseContent10": "服务变更",
  "TermsOfUseContent11": "perdate可以自行决定增加，删除或修改服务功能或各项服务，而无需事先通知。",
  "TermsOfUseContent12": "订制",
  "TermsOfUseContent13": "支付方式",
  "TermsOfUseContent14": "您的支付条款将基于您的支付方式上，支付条款由您和金融机构，信用卡发行机构或其他您选择的支付服务提供商（支付服务提供商）之间的协定来决定。如果perdate不接受您的“支付服务提供商”所提供的付款服务，您同意根据需要支付所有金额。您同意为使用我们的服务，支付所有的应付账款。如果您的账款已付，您可以请求我们取消您的已付账款的状态，一旦您的账户被取消，你的已付费状态将在您最后支付的日期时终止。已付费状态不能转让。perdate的已付费状态是最终销售，不能退款。有争议的费用应在您购买服务后的60天内上报给perdate。如对于您的已付费状态有何疑问，请联系我们。",
  "TermsOfUseContent15": "服务续约",
  "TermsOfUseContent16": "您在perdate网站订制的服务将不会自动续约。您可以联系我们的客服团队，随时变更或重新订制。如果您选择重新订制，您的订制服务在到期后将不能自动续约。在订制期满前取消订制的，不能得到退款。",
  "TermsOfUseContent17": "免费试用和其他促销",
  "TermsOfUseContent18": "任何免费试用或其他促销方式，可使订制者在特定的试用期限使用我们的服务。如果促销条款规定使用者需要订制服务，您应该在试用期之前取消订制，以避免交付订制费。",
  "TermsOfUseContent19": "通过合作伙伴加入perdate",
  "TermsOfUseContent20": "如果您通过perdate的合作伙伴注册使用我们的服务，并且perdate与其合作伙伴进行合作，提供该服务。你将有使用该服务的会员权利，并且perdate有权转移您的会员资格或将您的已付款账户转移到perdate的类似服务项目内。",
  "TermsOfUseContent21": "社区内容",
  "TermsOfUseContent22": "所有的服务内容都应该遵循社区内容指南的要求。您同意不发布，传送，分发或链接任何涉及违法，骚扰，毁谤，威胁，有害，猥亵，悖逆，诽谤，诋毁他人名誉，以及侵犯别人隐私的内容，也不发送其他宁人不悦或侵害其他人或团体权益的内容。未经知识产权人的书面同意，不得使用他人的知识产权，包括受版权和商标权保护的资料，变更或未变更的知识产权，其他人的非版权文本或图片等。perdate将不为会员所发的任何邮件或群讨论帖的内容负责，也不对第三方或会员提供的任何信息，商品或服务负责。使用我们的服务，即表明您同意：在以下情况下，perdate将不对您或其他人负责：例如：任何方的威胁，诽谤，猥亵，下流，攻击或违法行为，或侵权行为，包括违法使用知识产权。perdate不拥有您提供给所有信息（包括回馈和建议），或您在perdate所发布，下载，输入或提交的所有信息（“提交的信息”）。然而，如果您在我们的网站或客户端上发布，上传，输入，提供或提交信息，即表明您给予perdate永久不可撤销并且可转让的权利，perdate有权复制，使用，储存，修改，编辑，翻译或发布任何或全部您所提交的信息，并且无需支付信息的使用费。perdate没有义务发布或使用您所提交的信息，并且perdate可以随时自行决定删除您所提交的信息。你在本网站发布，下载，输入或提交信息，即表明您拥有您所发布信息的控制权。对于您的信息被删除，无效或储存失败，perdate和其合作方将不为此负责。",
  "TermsOfUseContent23": "会员账户",
  "TermsOfUseContent24": "一旦您注册了我们的服务，您将会收到一个账号和密码，您应对您的账户和密码保密，并对您账户相关的所有活动负责。一旦注册成为会员，您将为您档案的所有信息负责。禁止在档案或网站服务项目中发布色情或其他淫秽的内容，因为这样会威胁您的会员身份。对于perdate网站的会员进行的线下约会，perdate将不负任何责任。您同意perdate向您发送邮件（涉及服务信息（包括变更升级），新功能或事件，使用服务的意见和建议）。",
  "TermsOfUseContent25": "受版权保护和商标权保护的材料",
  "TermsOfUseContent26": "perdate网站的内容均受版权保护Copyright© 2011-2014。",
  "TermsOfUseContent27": "免责声明",
  "TermsOfUseContent28": "在perdate网站或通过perdate（或perdate的代理商或合作方）发布的资料，均按“现有”和“现存”提供。它并无各种明示或暗示的保证和条件。perdate不控制第三方所提供的任何信息，产品或服务。您明确同意，使用服务将独自承担风险。根据适用法例的最大容许程度：perdate就所有明确或隐含保证做出免责声明，而此等保证范围包括但不限于隐含的可销售性及特殊用途合适性保证；perdate并不保证所提供的服务能满足您的需求，也不保证服务将不中断，适时，安全或正确无误。perdate不为服务使用和使用的结果做担保。perdate也不保证本网站或服务项目不含任何病毒，或其他有害组件。perdate不保证或声明：保持网站传送信息的机密性。perdate不保证网站翻译的准确和完整。perdate不为以下做担保：通过本网站购买或获得的任何商品或服务，或在本网站做广告或赞助的商品或服务，或任何通过本网站所进行的交易。perdate不对您从perdate或其服务中所获得的信息做任何明示的保证（无论口头还是书面）。"
}

;

