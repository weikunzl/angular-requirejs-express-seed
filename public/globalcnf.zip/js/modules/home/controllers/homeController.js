/**
 * Created by wei
 *
 */
define(function(){
    'use strict';

    return ['$scope'
        , function($scope){

        	

    }]
})