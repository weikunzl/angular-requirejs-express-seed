/**
 * Created by WLxing on 16/3/28.
 */
//MySQL数据库连接配置
module.exports = {
    host : "/config",
    hostcfg : "/globalcnf",
    mysql: {
        host:'127.0.0.1',
        user: 'root',
        password:'vJYnmq6f9Rdv9ZM2',
        database:'oelove31',
        port: 3306
    }
};